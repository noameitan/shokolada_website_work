<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{opc}prestashop>header_88ae45a6236e4ef50a37a73d9960858f'] = 'PAIEMENT EXPRESS';
$_MODULE['<{opc}prestashop>header_027d94edb185043c66e8a00a24f64074'] = 'S\'il vous plaît entrer vos coordonnées ci-dessous pour terminer votre achat.';
$_MODULE['<{opc}prestashop>opc_ad3eb028f8ca15d304e5d17c642a619e'] = 'Module One Page Checkout transforme votre service de commande en tout-en-un formulaire rapide, qui exige le minimum de temps et d’efforts pour le remplir';
$_MODULE['<{opc}prestashop>order-address_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Adresses';
$_MODULE['<{opc}prestashop>order-carrier_6f05787682585c32498e88bcd2ea88fc'] = 'Modes de livraison';
$_MODULE['<{opc}prestashop>order-carrier_914419aa32f04011357d3b604a86d7eb'] = 'Porteur';
$_MODULE['<{opc}prestashop>order-opc-new-account_284b47b0bb63ae2df3b29f0e691d6fcf'] = 'Adresses';
$_MODULE['<{opc}prestashop>order-payment_f0aaaae189e9c7711931a65ffcd22543'] = 'Modes de paiement';
$_MODULE['<{opc}prestashop>shopping-cart_50a0ccc5f188dd81a49bbd921a864889'] = 'Vérifier la commande';
