<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{likeboxfree}prestashop>likeboxfree_9b9b30cc5124cb38a0b4f37bb3d2f0bb'] = 'Este módulo adiciona um bloco likebox especial com sua fanpage no Facebook. Agora qualquer um pode gostar de sua fanpage facebook!';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_f4d1ea475eaa85102e2b4e6d95da84bd'] = 'Confirmação';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_c888438d14855d7d96a2724ee9c306bd'] = 'Configurações atualizadas';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_7a7d57029c0de7a52035f23f44e94b38'] = 'Configuração Likebox';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_265bc69afdaf77a2b20642a84cb2b129'] = 'LikeBox Configurações Visual';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_a6105c0a611b41b08f1209506350279e'] = 'Sim';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_c19a11786e82b0736dc4735f1bd6e552'] = 'Facebook URL da página';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_381e99d9115db381c11785957d9e508d'] = 'A URL da página no Facebook para LikeBox';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_32954654ac8fe66a1d09be19001de2d4'] = 'Largura';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_9cddcd63ac79b2d3a082816b7f63f2a5'] = 'A largura do plugin LikeBox';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_eec6c4bdbd339edf8cbea68becb85244'] = 'Altura';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_623d21d65296ba114e9869f19750fd04'] = 'A altura do plugin LikeBox';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_83cccf4d0f83339c027ad7395fa4d0b9'] = 'Mostrar Faces';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_82432be27dcfce6316adae8964c64677'] = 'Mostrar fotos de perfil no plugin LikeBox';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_2e9864c4cae842d71fc0b5ffe1d9d7d2'] = 'Mostrar Stream';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_f2f74c24b7138f32c05a4dc259600b88'] = 'Mostrar fluxo perfil (na parede) no plugin LikeBox';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_a436543a292ec5bdd53083bcb1f4889f'] = 'Mostrar Encontra-nos no Facebook, barra na parte superior. Só mostra quando o Stream ou Faces estão ativados';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Salvar configurações';
$_MODULE['<{likeboxfree}prestashop>likeboxfree_701ce215fb238c7cd5b9aa57b08d79b0'] = 'Visualização Likebox ';
