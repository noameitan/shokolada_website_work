<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmbannerblock}prestashop>tmbannerblock_d59048f21fd887ad520398ce677be586'] = 'Leer más';
