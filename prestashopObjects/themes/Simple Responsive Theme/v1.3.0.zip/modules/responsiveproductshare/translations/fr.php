<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{responsiveproductshare}prestashop>responsiveproductshare_13eac0b6526cf812f4c7d6df498d9ac9'] = 'Partage produit responsive';
$_MODULE['<{responsiveproductshare}prestashop>responsiveproductshare_07af17c8892a87686e6415428c15a7d2'] = 'Ajoute un block de partage sur votre page produit';
